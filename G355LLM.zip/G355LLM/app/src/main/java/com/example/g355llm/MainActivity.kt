package com.example.g355llm

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                AppNavigation()
            }
        }
    }
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    NavHost(navController, startDestination = "main") {
        composable("main") { MainScreen(navController) }
        composable("qa") { PromptScreen(task = "qa") }
        composable("calendar") { PromptScreen(task = "calendar") }
    }
}

@Composable
fun MainScreen(navController: NavHostController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Offline AI Assistant", style = MaterialTheme.typography.titleLarge)

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = { navController.navigate("qa") },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Question Answering")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { navController.navigate("calendar") },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Calendar Tasks")
        }
    }
}

@Composable
fun PromptScreen(task: String) {
    var userPrompt by remember { mutableStateOf("") }
    var response by remember { mutableStateOf("Response will appear here") }

    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = if (task == "qa") "Question Answering" else "Calendar Tasks",
            style = MaterialTheme.typography.titleLarge
        )

        OutlinedTextField(
            value = userPrompt,
            onValueChange = { userPrompt = it },
            label = { Text("Enter your prompt") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {
                response = "Processing: $userPrompt"
                val fileName = if (task == "qa") "prompt.txt" else "calendar_prompt.txt"
                val responseFileName = if (task == "qa") "response.txt" else "calendar_response.txt"

                val inputFile = File(context.getExternalFilesDir(null), fileName)
                inputFile.writeText(userPrompt)

                val responseFile = File(context.getExternalFilesDir(null), responseFileName)
                response = if (responseFile.exists()) {
                    responseFile.readText()
                } else {
                    "No response yet"
                }
            }
        ) {
            Text("Send")
        }

        Text(
            text = response,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
